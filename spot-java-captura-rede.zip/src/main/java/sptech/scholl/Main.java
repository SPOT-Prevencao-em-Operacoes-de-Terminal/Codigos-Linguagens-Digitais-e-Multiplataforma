package sptech.scholl;

import org.springframework.jdbc.core.JdbcTemplate;

public class Main {

    public static void main(String[] args) {
        try {
            System.out.println("===== SPOT =====");
            System.out.println("Monitoramento de rede");
            System.out.println();

            Monitoramento monitoramento = new Monitoramento();

            Conexao conexao = new Conexao();
            JdbcTemplate jdbcTemplate = new JdbcTemplate(conexao.getDataSource());

            String sql = "INSERT INTO leitura (valor, dia_hora, fk_configComponente, fk_configServidor) VALUES (?, NOW(), ?, ?)";
            Long totalAnterior = 0L;
            Boolean primeiraCaptura = true;
            //captura
            while (true) {
                Rede rede = monitoramento.capturarRede();

                System.out.println("Interface: " + rede.getNomeInterface());
                System.out.println("Bytes recebidos: " + rede.getBytesRecebidos());
                System.out.println("Bytes enviados: " + rede.getBytesEnviados());

                Long totalAtual = rede.getBytesRecebidos() + rede.getBytesEnviados();
                System.out.println("Total atual: " + totalAtual);

                if (primeiraCaptura == false) {

                    Long diferenca = totalAtual - totalAnterior;
                    Double megabytesPorSegundo = (diferenca / 1024.0 / 1024.0) / 10.0;
                    System.out.println("Tráfego: " + megabytesPorSegundo + " MB/s");

                    jdbcTemplate.update(sql, megabytesPorSegundo, 6, 1);
                    System.out.println();
                    System.out.println("Leitura inserida no banco!");

                } else {
                    System.out.println("Primeira captura usada como base.");
                    primeiraCaptura = false;
                }

                totalAnterior = totalAtual;

                System.out.println("Aguardando 10 segundos...");
                Thread.sleep(10000);

                System.out.println("-------------------------");

            }

        } catch (Exception e) {
            System.out.println("Erro no programa:");
            System.out.println(e.getMessage());
        }
    }
}